We would like the 63 boards in a panel of 9x7 PCB (total size approximately 11"x9") with 0.5" border and 0.1" spacing between PCBs. The panel should be routed with tabs and perforation.

Please add at least 3 fiducials on the border of the panel. Each fiducial marker should be at least .025in. away from any soldermask or traces.
Fiducial markers comprised of round unmasked etched pads 1mm / .040in. in diameter are prefered.

