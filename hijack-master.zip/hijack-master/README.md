hijack
======

Hardware and software for smartphone sensor peripherals using the audio jack interface.
