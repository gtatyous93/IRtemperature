package umich.hijack.core;

public enum SignalLevel {
	HIGH,
	LOW,
	FLOATING
}
