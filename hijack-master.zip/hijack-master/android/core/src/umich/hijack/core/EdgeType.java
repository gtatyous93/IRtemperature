package umich.hijack.core;

public enum EdgeType {
	RISING,
	FALLING
}
