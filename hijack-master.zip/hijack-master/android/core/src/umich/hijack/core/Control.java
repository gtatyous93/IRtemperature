package umich.hijack.core;


import umich.hijack.core.Packet;
import umich.hijack.core.PacketDispatch;
import umich.hijack.core.PktRecvCb;
import umich.hijack.core.SerialDecoder;

import android.annotation.SuppressLint;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Environment;

public class Control {
	
	private SerialDecoder _serialDecoder;
	private PacketDispatch _dispatcher;
	
	private void pinMode() {

	}
	
	private void digitalWrite() {
		
	}
	
	private void digitalRead() {
		
	}
	
	private void analogRead() {
		
	}
	
	private void analogWrite() {
		
	}
	
	private void interrupts() {
		
	}
	
	private void noInterrupts() {
		
	}
	
	

}
