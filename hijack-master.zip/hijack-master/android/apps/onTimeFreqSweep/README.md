On Time Frequency Sweep App
===========================

Sweeps the frequency and logs all power state events. This logged file can then
be processed to determine the duty cycle at each frequency.

