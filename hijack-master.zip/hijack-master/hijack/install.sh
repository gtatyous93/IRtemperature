#!/bin/bash

tup upd
tos-bsl --swap-reset-test --invert-reset --invert-test -r -e -I -p build-f1611/out.hex
